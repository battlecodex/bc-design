---
name: bc-ui-styling
description: Use when implementing or restyling an interface's visual layer while preserving its routes, data contracts, interaction semantics, and approved behavior.
---

# BC UI Styling

Use this skill for implementation work after the direction and invariants are clear. It turns the contract into responsive, accessible code without silently redesigning product behavior.

## Workflow

1. Detect the actual stack from project files; never assume React or Tailwind.
2. Inventory routes, components, content hierarchy, tokens, and preserved behavior.
3. Apply shared tokens and typography before one-off selectors.
4. Implement responsive structure at 375px, 768px, 1024px, and 1440px.
5. Cover default, hover, active, focus-visible, disabled, loading, empty, and error states.
6. Verify keyboard order, touch targets, contrast, wrapping, reduced motion, and streamed content stability.
7. Run the BC source audit and report rendered states that were not observed.

## Non-negotiables

- Do not change routes, data, navigation, or semantics during a restyle without approval.
- Keep interface copy active and meaningful; remove decorative arrow suffixes and filler metadata.
- Use purposeful 1.5px monoline SVG icons with accessible names.
- Use motion tokens and avoid layout-property animation for streamed output.
- Keep fallbacks explicit when a font, image, or browser feature is unavailable.

## References

- Shared foundation: `../bc-design/SKILL.md`
- Stack notes: `../bc-design/stacks/`
- Component guidance: `../bc-design/references/components.md`
- Motion guidance: `../bc-motion/SKILL.md`
